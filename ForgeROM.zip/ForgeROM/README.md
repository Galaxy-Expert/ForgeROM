# ForgeROM 0.1 Very Alpha

Finds suitable custom ROMs and recoveries for your Android phone.

## How the search works
1. **Free search (no key):** by device codename it checks the LineageOS wiki device data
   (official ROM, supported model numbers, bootloader "not unlockable" flag), the OrangeFox API
   and the TWRP download page.
2. **AI deep search (optional):** with the user's own Anthropic API key it researches the web for
   unofficial ROMs / XDA threads and double-checks the bootloader status. Results are merged with the free ones.

Two modes: suggestion mode (no root, never changes the device) and root mode (asks for su permission).

## App icon (two layers)
Replace these two files with your own 512x512 PNGs (same names):

    app/src/main/res/drawable-xxxhdpi/ic_launcher_background.png   (full square, no transparency needed)
    app/src/main/res/drawable-xxxhdpi/ic_launcher_foreground.png   (transparent background)

Keep the important part of the foreground inside the centre ~310 px of the 512 px canvas;
Android crops the edges depending on the phone's icon shape.

Without a computer: upload the files to the repository root as `icon_background.png` and
`icon_foreground.png`. The GitHub workflow copies them into the project before building.

## Translations
See TRANSLATING.md.
