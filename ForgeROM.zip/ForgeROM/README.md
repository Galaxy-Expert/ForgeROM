# ForgeROM

Finds suitable custom ROMs and recoveries for your Android phone.

## How the search works
1. **Free search (no key):** by device codename it checks the LineageOS wiki device data
   (official ROM, supported model numbers, bootloader "not unlockable" flag), the crDroid download list,
   the OrangeFox API and the TWRP download page.
2. **AI deep search (optional):** with the user's own Anthropic API key it researches the web for
   unofficial ROMs / XDA threads and double-checks the bootloader status. Results are merged with the free ones.

Two modes: suggestion mode (no root, never changes the device) and root mode (asks for su permission).

## App icon (two layers)
Replace these two files with your own 512x512 PNGs (same names):

    app/src/main/res/drawable-xxxhdpi/ic_launcher_background.png   (full square, no transparency needed)
    app/src/main/res/drawable-xxxhdpi/ic_launcher_foreground.png   (transparent background)

Keep the important part of the foreground inside the centre ~310 px of the 512 px canvas;
Android crops the edges depending on the phone's icon shape.

Without a computer: upload the files to the repository root as `icon_background.png` and
`icon_foreground.png`. The GitHub workflow copies them into the project before building.

## Translations
See TRANSLATING.md.

## Release signing
Release APKs are signed with a fixed key so updates install over older versions.
The key lives only in the repository secrets `SIGNING_KEYSTORE_BASE64` and `SIGNING_PASSWORD`
(alias `forgerom`). Never commit the keystore. If the secrets are missing (for example in a fork),
the build falls back to the debug key.

## Privacy
- The optional AI search uses your own Anthropic API key. It is stored encrypted with the Android Keystore, only on your device.
- The free search sends the device codename to the LineageOS wiki data (GitHub), the OrangeFox API and the TWRP download site.

## Saved results
Results are saved on the device per phone model for 30 days and shown again when you open the app or pick that device
(with a small "saved results" note). "Search again" always goes online and replaces the saved copy.

## Reporting problems
"Report a problem" opens a GitHub issue with your device, app version and results filled in.
You review it and submit it yourself; nothing is sent automatically. The API key is never included.

## Downloads
When LineageOS' official download API gives a direct link, the ROM card shows a Download button
(file name, size and SHA-256 are shown first). The file goes to your Downloads folder through Android's
DownloadManager; only HTTPS links from lineageos.org hosts are allowed. ForgeROM never installs anything.
A read-only install checklist explains the general steps.

## Updates and crashes
- Once a day (can be turned off in Settings) the app reads the GitHub releases list and shows a card when a newer version exists.
  Only a normal web request is made; nothing about you is sent.
- If the app crashes, a short summary is saved on the device. On the next launch you can send it as a pre-filled GitHub issue
  after reviewing it. Nothing is sent automatically.

## Checks in the build
The workflow validates the string resources (the kind of mistake that broke an early build), runs the parser unit tests
(without blocking the build) and signs the release APK with the repository's signing secrets.
