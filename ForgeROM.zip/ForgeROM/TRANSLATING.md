# Translating ForgeROM

All user-facing text lives in Android string resources, so translating needs no coding.

1. Copy `app/src/main/res/values/strings.xml` to `app/src/main/res/values-<code>/strings.xml`
   (for example `values-de` for German, `values-pt-rBR` for Brazilian Portuguese).
2. Translate only the text between the tags. Do not change the `name="..."` parts.
3. Keep placeholders such as `%1$s` and `%2$d` exactly as they are.
4. Escape apostrophes with a backslash: `don\'t`.
5. Add the language code to `app/src/main/res/xml/locales_config.xml`:
   `<locale android:name="de" />`
6. Add the language to the list in `app/src/main/java/com/forgerom/app/Languages.kt`:
   `Language("de", "Deutsch")`

Missing strings automatically fall back to English.
The AI research notes are written in the language the app is currently set to.
