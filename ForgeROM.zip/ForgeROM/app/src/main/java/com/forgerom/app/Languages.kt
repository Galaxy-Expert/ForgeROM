package com.forgerom.app

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

data class Language(val tag: String, val nativeName: String)

/**
 * Languages shown in the language picker.
 * To add one: create res/values-<tag>/strings.xml, add the tag to res/xml/locales_config.xml,
 * and add a line here. See TRANSLATING.md.
 */
object Languages {
    val all = listOf(
        Language("en", "English"),
        Language("tr", "Türkçe")
    )

    fun setLanguage(tag: String) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
    }
}
