package com.forgerom.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.forgerom.app.ui.ForgeRomApp
import com.forgerom.app.ui.ForgeRomTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Üst çubuk mavi gradient'in üstüne biner; ikonlar açık renk olsun.
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT))
        setContent {
            ForgeRomTheme {
                val vm: MainViewModel = viewModel()
                val state by vm.state.collectAsStateWithLifecycle()
                ForgeRomApp(
                    state = state,
                    onApiKeyChange = vm::setApiKey,
                    onSearch = vm::search,
                    onOpenPicker = vm::openPicker,
                    onClosePicker = vm::closePicker,
                    onPickerQuery = vm::onPickerQuery,
                    onSelectManual = vm::selectManual,
                    onUseDetected = vm::useDetected
                )
            }
        }
    }
}
