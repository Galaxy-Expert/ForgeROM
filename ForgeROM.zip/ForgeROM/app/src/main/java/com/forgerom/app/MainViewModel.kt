package com.forgerom.app

import android.app.Application
import android.content.Context
import androidx.annotation.StringRes
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.forgerom.app.ai.BootloaderStatus
import com.forgerom.app.ai.RomFinder
import com.forgerom.app.ai.RomSearchResult
import com.forgerom.app.ai.UserFacingException
import com.forgerom.app.device.BootloaderPolicy
import com.forgerom.app.device.CatalogEntry
import com.forgerom.app.device.DeviceCatalog
import com.forgerom.app.device.DeviceInfo
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

enum class Screen { ONBOARDING, MAIN, PICKER, SETTINGS }

/** SUGGEST = no root, never changes the device. ROOT = asks for su permission. */
enum class AppMode { SUGGEST, ROOT }

data class UiError(@StringRes val res: Int, val detail: String = "")
data class Notice(@StringRes val res: Int, val positive: Boolean)

data class UiState(
    val screen: Screen = Screen.MAIN,
    val mode: AppMode = AppMode.SUGGEST,
    val rootGranted: Boolean = false,
    val rootChecking: Boolean = false,
    val notice: Notice? = null,
    val detected: DeviceInfo? = null,
    val detectedName: String? = null,
    val resolvingName: Boolean = true,
    val manual: CatalogEntry? = null,          // manually selected device (replaces the detected one)
    val apiKey: String = "",
    val searching: Boolean = false,
    val result: RomSearchResult? = null,
    val error: UiError? = null,
    val pickerQuery: String = "",
    val pickerResults: List<CatalogEntry> = emptyList(),
    val pickerLoading: Boolean = false
) {
    /** The device used for searching: the manual selection if any, otherwise the detected one. */
    val activeDevice: DeviceInfo?
        get() = manual?.let { m ->
            DeviceInfo(
                manufacturer = m.brand, brand = m.brand, model = m.model, codename = m.codename,
                androidVersion = "", sdk = 0, soc = null
            )
        } ?: detected

    val activeName: String? get() = manual?.name ?: detectedName

    /** "Samsung Galaxy S20 FE SM-G780G (r8q)" or null while the device is still being detected. */
    val displayName: String?
        get() {
            val d = activeDevice ?: return null
            val base = activeName ?: d.manufacturer.replaceFirstChar { it.uppercase() }
            return "$base ${d.model} (${d.codename})".trim()
        }
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("forgerom", Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS) // web search can take a while
        .build()
    private val catalog = DeviceCatalog(app, client)
    private val finder = RomFinder(client)
    private var pickerJob: Job? = null

    private val _state = MutableStateFlow(
        UiState(
            screen = if (prefs.getBoolean("onboarded", false)) Screen.MAIN else Screen.ONBOARDING,
            apiKey = prefs.getString("api_key", "").orEmpty()
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        val device = DeviceInfo.fromBuild()
        _state.update { it.copy(detected = device) }
        viewModelScope.launch {
            val entry = catalog.resolve(device)
            _state.update { it.copy(detectedName = entry?.name, resolvingName = false) }
        }
        // Returning user who chose root mode: check su again (no prompt if already allowed).
        if (prefs.getString("mode", "suggest") == "root" && prefs.getBoolean("onboarded", false)) {
            applyMode(AppMode.ROOT)
        }
    }

    // ---- Onboarding, mode and settings ----

    fun completeOnboarding(mode: AppMode) {
        applyMode(mode) {
            prefs.edit().putBoolean("onboarded", true).apply()
            _state.update { it.copy(screen = Screen.MAIN) }
        }
    }

    fun setMode(mode: AppMode) = applyMode(mode)
    fun recheckRoot() = applyMode(AppMode.ROOT)

    private fun applyMode(mode: AppMode, onDone: () -> Unit = {}) {
        if (mode == AppMode.SUGGEST) {
            prefs.edit().putString("mode", "suggest").apply()
            _state.update { it.copy(mode = AppMode.SUGGEST, rootGranted = false) }
            onDone()
            return
        }
        _state.update { it.copy(rootChecking = true) }
        viewModelScope.launch {
            val granted = RootManager.requestRoot()
            prefs.edit().putString("mode", if (granted) "root" else "suggest").apply()
            _state.update {
                it.copy(
                    mode = if (granted) AppMode.ROOT else AppMode.SUGGEST,
                    rootGranted = granted,
                    rootChecking = false,
                    notice = Notice(if (granted) R.string.root_granted else R.string.root_denied, granted)
                )
            }
            onDone()
        }
    }

    fun openSettings() = _state.update { it.copy(screen = Screen.SETTINGS) }
    fun closeSettings() = _state.update { it.copy(screen = Screen.MAIN) }
    fun dismissNotice() = _state.update { it.copy(notice = null) }

    fun setApiKey(key: String) {
        val clean = key.trim()
        prefs.edit().putString("api_key", clean).apply()
        _state.update { it.copy(apiKey = clean) }
    }

    // ---- Manual device selection ----

    fun openPicker() = _state.update { it.copy(screen = Screen.PICKER, pickerQuery = "", pickerResults = emptyList()) }
    fun closePicker() = _state.update { it.copy(screen = Screen.MAIN) }

    fun onPickerQuery(q: String) {
        _state.update { it.copy(pickerQuery = q, pickerLoading = q.isNotBlank()) }
        pickerJob?.cancel()
        pickerJob = viewModelScope.launch {
            delay(150)
            val r = catalog.search(q)
            _state.update { it.copy(pickerResults = r, pickerLoading = false) }
        }
    }

    fun selectManual(entry: CatalogEntry) =
        _state.update { it.copy(manual = entry, screen = Screen.MAIN, result = null, error = null) }

    fun useDetected() = _state.update { it.copy(manual = null, result = null, error = null) }

    // ---- ROM / recovery search ----

    /** [language] is the English name of the UI language (e.g. "Turkish"); the AI writes its notes in it. */
    fun search(language: String) {
        val s = _state.value
        val device = s.activeDevice ?: return

        // A local rule (future ready-made database) says locked: skip the API call entirely.
        BootloaderPolicy.check(device)?.let { bl ->
            if (bl.status == BootloaderStatus.LOCKED) {
                _state.update {
                    it.copy(error = null, result = RomSearchResult(null, bl, emptyList(), emptyList(), emptyList()))
                }
                return
            }
        }

        if (s.apiKey.isBlank()) {
            _state.update { it.copy(error = UiError(R.string.err_no_api_key)) }
            return
        }
        _state.update { it.copy(searching = true, error = null, result = null) }
        viewModelScope.launch {
            try {
                val r = finder.find(s.apiKey, device, s.activeName, language)
                _state.update {
                    it.copy(
                        searching = false,
                        result = r,
                        detectedName = if (it.manual == null) it.detectedName ?: r.marketingName else it.detectedName
                    )
                }
            } catch (e: UserFacingException) {
                _state.update { it.copy(searching = false, error = UiError(e.res, e.detail)) }
            } catch (e: Exception) {
                _state.update {
                    it.copy(searching = false, error = UiError(R.string.err_generic, e.message ?: e.javaClass.simpleName))
                }
            }
        }
    }
}
