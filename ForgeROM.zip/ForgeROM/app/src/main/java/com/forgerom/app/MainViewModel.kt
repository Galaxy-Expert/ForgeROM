package com.forgerom.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.forgerom.app.ai.BootloaderStatus
import com.forgerom.app.ai.RomFinder
import com.forgerom.app.ai.RomSearchResult
import com.forgerom.app.device.BootloaderPolicy
import com.forgerom.app.device.CatalogEntry
import com.forgerom.app.device.DeviceCatalog
import com.forgerom.app.device.DeviceInfo
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

enum class Screen { MAIN, PICKER }

data class UiState(
    val screen: Screen = Screen.MAIN,
    val detected: DeviceInfo? = null,
    val detectedName: String? = null,
    val resolvingName: Boolean = true,
    val manual: CatalogEntry? = null,          // elle seçilen cihaz (varsa algılananın yerine geçer)
    val apiKey: String = "",
    val searching: Boolean = false,
    val result: RomSearchResult? = null,
    val error: String? = null,
    val pickerQuery: String = "",
    val pickerResults: List<CatalogEntry> = emptyList(),
    val pickerLoading: Boolean = false
) {
    /** Arama için kullanılacak cihaz: elle seçilen, yoksa algılanan. */
    val activeDevice: DeviceInfo?
        get() = manual?.let { m ->
            DeviceInfo(
                manufacturer = m.brand, brand = m.brand, model = m.model, codename = m.codename,
                androidVersion = "", sdk = 0, soc = null
            )
        } ?: detected

    val activeName: String? get() = manual?.name ?: detectedName

    /** "Samsung Galaxy S20 FE SM-G780G (r8q)" biçimi */
    val displayName: String
        get() {
            val d = activeDevice ?: return "Cihaz algılanıyor…"
            val base = activeName ?: d.manufacturer.replaceFirstChar { it.uppercase() }
            return "$base ${d.model} (${d.codename})".trim()
        }
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("forgerom", Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS) // web araması uzun sürebilir
        .build()
    private val catalog = DeviceCatalog(app, client)
    private val finder = RomFinder(client)
    private var pickerJob: Job? = null

    private val _state = MutableStateFlow(
        UiState(apiKey = prefs.getString("api_key", "").orEmpty())
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        val device = DeviceInfo.fromBuild()
        _state.update { it.copy(detected = device) }
        viewModelScope.launch {
            val entry = catalog.resolve(device)
            _state.update { it.copy(detectedName = entry?.name, resolvingName = false) }
        }
    }

    fun setApiKey(key: String) {
        val clean = key.trim()
        prefs.edit().putString("api_key", clean).apply()
        _state.update { it.copy(apiKey = clean) }
    }

    // ---- Manuel model seçimi ----
    fun openPicker() = _state.update { it.copy(screen = Screen.PICKER, pickerQuery = "", pickerResults = emptyList()) }
    fun closePicker() = _state.update { it.copy(screen = Screen.MAIN) }

    fun onPickerQuery(q: String) {
        _state.update { it.copy(pickerQuery = q, pickerLoading = q.isNotBlank()) }
        pickerJob?.cancel()
        pickerJob = viewModelScope.launch {
            delay(150)
            val r = catalog.search(q)
            _state.update { it.copy(pickerResults = r, pickerLoading = false) }
        }
    }

    fun selectManual(entry: CatalogEntry) =
        _state.update { it.copy(manual = entry, screen = Screen.MAIN, result = null, error = null) }

    fun useDetected() = _state.update { it.copy(manual = null, result = null, error = null) }

    // ---- ROM / recovery arama ----
    fun search() {
        val s = _state.value
        val device = s.activeDevice ?: return

        // Yerel kural (ileride hazır veritabanı) kilitli diyorsa API'ye hiç gitme.
        BootloaderPolicy.check(device)?.let { bl ->
            if (bl.status == BootloaderStatus.LOCKED) {
                _state.update {
                    it.copy(error = null, result = RomSearchResult(null, bl, emptyList(), emptyList(), emptyList()))
                }
                return
            }
        }

        if (s.apiKey.isBlank()) {
            _state.update { it.copy(error = "Önce bir API anahtarı gir.") }
            return
        }
        _state.update { it.copy(searching = true, error = null, result = null) }
        viewModelScope.launch {
            try {
                val r = finder.find(s.apiKey, device, s.activeName)
                _state.update {
                    it.copy(
                        searching = false,
                        result = r,
                        detectedName = if (it.manual == null) it.detectedName ?: r.marketingName else it.detectedName
                    )
                }
            } catch (e: Exception) {
                _state.update { it.copy(searching = false, error = e.message ?: "Bilinmeyen hata") }
            }
        }
    }
}
