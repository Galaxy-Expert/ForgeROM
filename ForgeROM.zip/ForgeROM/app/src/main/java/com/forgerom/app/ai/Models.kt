package com.forgerom.app.ai

import androidx.annotation.StringRes
import java.io.IOException

enum class BootloaderStatus { UNLOCKABLE, CONDITIONAL, LOCKED, UNKNOWN }

data class BootloaderInfo(
    val status: BootloaderStatus,
    val notes: String?
)

data class RomItem(
    val name: String,
    val androidVersion: String?,
    val status: String?,   // official / unofficial / abandoned
    val url: String,
    val notes: String?
)

data class RecoveryItem(
    val name: String,
    val url: String,
    val notes: String?
)

data class RomSearchResult(
    val marketingName: String?,
    val bootloader: BootloaderInfo,
    val roms: List<RomItem>,
    val recoveries: List<RecoveryItem>,
    val warnings: List<String>
)

/** An error whose message is a translatable string resource (+ optional technical detail). */
class UserFacingException(
    @StringRes val res: Int,
    val detail: String = ""
) : IOException(detail)
