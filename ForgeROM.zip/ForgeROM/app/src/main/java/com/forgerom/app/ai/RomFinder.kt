package com.forgerom.app.ai

import com.forgerom.app.device.DeviceInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/**
 * Anthropic Messages API + web_search aracı ile cihaza uygun ROM/recovery arar.
 * XDA'nın API'si olmadığı için sayfa kazımak yerine web araştırması yaptırıyoruz.
 */
class RomFinder(private val client: OkHttpClient) {

    suspend fun find(
        apiKey: String,
        device: DeviceInfo,
        marketingName: String?
    ): RomSearchResult = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 4096)
            .put("system", SYSTEM_PROMPT)
            .put(
                "tools",
                JSONArray().put(
                    JSONObject()
                        .put("type", "web_search_20250305")
                        .put("name", "web_search")
                        .put("max_uses", 6)
                )
            )
            .put(
                "messages",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("content", buildUserPrompt(device, marketingName))
                )
            )

        val request = Request.Builder()
            .url(API_URL)
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw IOException("API hatası (${resp.code}): ${extractError(raw)}")
            }
            parse(raw)
        }
    }

    private fun buildUserPrompt(d: DeviceInfo, marketingName: String?): String = buildString {
        appendLine("Cihaz bilgileri:")
        appendLine("- Üretici: ${d.manufacturer}")
        appendLine("- Gerçek model adı: ${marketingName ?: "bilinmiyor, web'den bul"}")
        appendLine("- Model numarası: ${d.model}")
        appendLine("- Kod adı (codename): ${d.codename}")
        if (d.sdk > 0) appendLine("- Mevcut Android sürümü: ${d.androidVersion} (API ${d.sdk})")
        d.soc?.let { appendLine("- SoC: $it") }
        appendLine()
        append("Bu cihaz için uygun custom ROM'ları ve custom recovery'leri bul.")
    }

    private fun parse(raw: String): RomSearchResult {
        val content = JSONObject(raw).getJSONArray("content")
        val text = buildString {
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") append(block.optString("text"))
            }
        }
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) throw IOException("Yapay zeka geçerli bir sonuç döndürmedi.")
        val json = JSONObject(text.substring(start, end + 1))

        val roms = json.optJSONArray("roms").mapObjects { o ->
            val url = o.optString("url")
            if (!url.isHttpUrl()) null
            else RomItem(
                name = o.optString("name"),
                androidVersion = o.optString("android_version").ifBlank { null },
                status = o.optString("status").ifBlank { null },
                url = url,
                notes = o.optString("notes").ifBlank { null }
            )
        }
        val recoveries = json.optJSONArray("recoveries").mapObjects { o ->
            val url = o.optString("url")
            if (!url.isHttpUrl()) null
            else RecoveryItem(
                name = o.optString("name"),
                url = url,
                notes = o.optString("notes").ifBlank { null }
            )
        }
        val warnings = buildList {
            val arr = json.optJSONArray("warnings")
            if (arr != null) for (i in 0 until arr.length()) add(arr.optString(i))
        }
        val bl = json.optJSONObject("bootloader")
        val blStatus = when (bl?.optString("status")?.lowercase()) {
            "unlockable" -> BootloaderStatus.UNLOCKABLE
            "conditional" -> BootloaderStatus.CONDITIONAL
            "locked" -> BootloaderStatus.LOCKED
            else -> BootloaderStatus.UNKNOWN
        }
        val bootloader = BootloaderInfo(blStatus, bl?.optString("notes")?.ifBlank { null })
        val locked = blStatus == BootloaderStatus.LOCKED
        return RomSearchResult(
            marketingName = json.optString("marketing_name").ifBlank { null },
            bootloader = bootloader,
            roms = if (locked) emptyList() else roms,
            recoveries = if (locked) emptyList() else recoveries,
            warnings = warnings
        )
    }

    private fun extractError(raw: String): String = try {
        JSONObject(raw).getJSONObject("error").optString("message", raw)
    } catch (e: Exception) {
        raw.take(200)
    }

    private fun String.isHttpUrl() = startsWith("https://") || startsWith("http://")

    private fun <T> JSONArray?.mapObjects(transform: (JSONObject) -> T?): List<T> {
        if (this == null) return emptyList()
        val out = ArrayList<T>()
        for (i in 0 until length()) optJSONObject(i)?.let { o -> transform(o)?.let(out::add) }
        return out
    }

    companion object {
        // Model ve araç sürümü zamanla değişebilir; gerekirse buradan güncelle.
        const val MODEL = "claude-sonnet-5-5"
        private const val API_URL = "https://api.anthropic.com/v1/messages"

        private val SYSTEM_PROMPT = """
Sen ForgeROM uygulamasının araştırma asistanısın. Verilen Android cihaz için web'de
(XDA Developers, LineageOS wiki, TWRP, OrangeFox, PitchBlack, ROM'ların resmi siteleri vb.)
arama yapıp cihaza uygun custom ROM ve custom recovery bul.

ÖNCE bu cihazın TAM model/varyant/bölge kombinasyonu için bootloader kilidinin açılıp açılamadığını araştır
(operatör/bölge varyantları, üreticinin OEM unlock politikası, kilit açma programlarının kapatılması vb.).
- Açılabiliyorsa "unlockable", sadece belirli koşullarda açılabiliyorsa (operatör, bölge, bekleme süresi, üretici hesabı vb.) "conditional",
  resmi veya pratik olarak açılamıyorsa "locked", kesin bilgi bulamadıysan "unknown" yaz. "notes" alanına kısa gerekçe ve kaynağı yaz.
- "locked" ise roms ve recoveries listelerini boş bırak.

Kurallar:
- Sadece sayfasında bu cihazın kod adı veya model numarası açıkça geçen sonuçları ekle.
- URL uydurma. Sadece araştırmada gerçekten gördüğün URL'leri ver.
- Resmi / gayriresmi / terk edilmiş durumunu belirt. Eski ve bakımsız projeleri tercih etme.
- Aynı model adının farklı donanım varyantları varsa (ör. Exynos / Snapdragon, 4G / 5G) uyarılara yaz.
- En fazla 5 ROM ve 3 recovery ver.
- Bootloader kilidi, garanti, veri kaybı gibi önemli riskleri "warnings" içine kısaca yaz.
- Tüm metin alanlarını Türkçe yaz.
- Emin değilsen o öğeyi ekleme. Boş liste vermek yanlış öneri vermekten iyidir.

SADECE şu JSON nesnesiyle yanıt ver, markdown veya ek açıklama ekleme:
{
  "marketing_name": "Cihazın gerçek ticari adı veya null",
  "bootloader": {"status": "unlockable|conditional|locked|unknown", "notes": ""},
  "roms": [
    {"name": "", "android_version": "", "status": "official|unofficial|abandoned", "url": "", "notes": ""}
  ],
  "recoveries": [
    {"name": "", "url": "", "notes": ""}
  ],
  "warnings": [""]
}
        """.trimIndent()
    }
}
