package com.forgerom.app.device

import com.forgerom.app.ai.BootloaderInfo

/**
 * Yerel (hazır veritabanı) bootloader kuralları için yer.
 *
 * Şimdilik boş: kilit durumu yapay zeka araştırmasından geliyor.
 * İleride buraya parametreli kurallar eklenecek, örneğin:
 *   - Samsung + Android 16 ve sonrası  -> BootloaderStatus.LOCKED
 * null döndürmek "yerel kural yok, yapay zekaya bırak" demektir.
 * LOCKED dönerse arama yapılmaz (API maliyeti de olmaz).
 */
object BootloaderPolicy {
    fun check(device: DeviceInfo): BootloaderInfo? = null
}
