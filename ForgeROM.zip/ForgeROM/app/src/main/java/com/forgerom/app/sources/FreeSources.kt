package com.forgerom.app.sources

import com.forgerom.app.R
import com.forgerom.app.ai.BootloaderInfo
import com.forgerom.app.ai.BootloaderStatus
import com.forgerom.app.ai.RecoveryItem
import com.forgerom.app.ai.RomItem
import com.forgerom.app.ai.UiText
import com.forgerom.app.device.DeviceInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

data class FreeResult(
    val marketingName: String?,
    val bootloader: BootloaderInfo?,
    val roms: List<RomItem>,
    val recoveries: List<RecoveryItem>,
    val warnings: List<UiText>
)

/**
 * Free, key-less sources queried by device codename:
 *  - LineageOS wiki device data (official ROM, supported models, "is_unlockable" flag)
 *  - OrangeFox public API (official recovery)
 *  - TWRP download page (official recovery)
 * Every source is best-effort: if one fails or the device is unknown there, it is simply skipped.
 */
class FreeSources(private val client: OkHttpClient) {

    suspend fun search(device: DeviceInfo): FreeResult = coroutineScope {
        val code = device.codename.trim()
        if (!CODENAME.matches(code)) {
            return@coroutineScope FreeResult(null, null, emptyList(), emptyList(), emptyList())
        }
        val lineage = async(Dispatchers.IO) { runCatching { lineage(code, device.model) }.getOrNull() }
        val fox = async(Dispatchers.IO) { runCatching { orangeFox(code) }.getOrNull() }
        val twrp = async(Dispatchers.IO) { runCatching { twrp(code) }.getOrNull() }

        val l = lineage.await()
        FreeResult(
            marketingName = l?.marketingName,
            bootloader = l?.bootloader,
            roms = listOfNotNull(l?.rom),
            recoveries = listOfNotNull(fox.await(), twrp.await()),
            warnings = l?.warnings.orEmpty()
        )
    }

    // ───────── LineageOS ─────────

    private class LineageInfo(
        val marketingName: String?,
        val rom: RomItem,
        val bootloader: BootloaderInfo,
        val warnings: List<UiText>
    )

    private fun lineage(code: String, model: String): LineageInfo? {
        val lc = code.lowercase()
        val docs = ArrayList<Map<String, String>>()
        getText("$LINEAGE_DATA/$lc.yml")?.let { docs += parseYaml(it) }
        if (docs.isEmpty()) {
            // Devices with several hardware variants are stored as <codename>_variantN.yml
            for (i in 1..4) getText("$LINEAGE_DATA/${lc}_variant$i.yml")?.let { docs += parseYaml(it) }
        }
        if (docs.isEmpty()) return null

        val wanted = normalizeModel(model)
        val d = docs.firstOrNull { doc -> parseList(doc["models"]).any { normalizeModel(it) == wanted } } ?: docs.first()

        val title = listOfNotNull(d["vendor"], d["name"]).joinToString(" ").trim()
        val branch = d["current_branch"] ?: parseList(d["versions"]).lastOrNull()
        val discontinued = parseList(d["channels"]).any { it.equals("discontinued", ignoreCase = true) }

        val rom = RomItem(
            name = if (branch != null) "LineageOS $branch" else "LineageOS",
            androidVersion = branch?.let { lineageToAndroid(it) },
            status = if (discontinued) "abandoned" else "official",
            url = "https://wiki.lineageos.org/devices/$lc/",
            notes = UiText.res(R.string.note_lineage, title.ifBlank { code })
        )

        val unlockable = !(d["is_unlockable"]?.equals("false", ignoreCase = true) ?: false)
        val bootloader = if (unlockable) {
            BootloaderInfo(BootloaderStatus.UNLOCKABLE, UiText.res(R.string.bl_lineage_ok))
        } else {
            BootloaderInfo(BootloaderStatus.LOCKED, UiText.res(R.string.bl_lineage_locked))
        }

        val warnings = ArrayList<UiText>()
        val models = parseList(d["models"])
        if (models.isNotEmpty() && model.isNotBlank() && models.none { normalizeModel(it) == wanted }) {
            warnings += UiText.res(R.string.warn_model_not_listed, model)
        }
        return LineageInfo(title.ifBlank { null }, rom, bootloader, warnings)
    }

    /** LineageOS version -> Android version (null when unknown). */
    private fun lineageToAndroid(branch: String): String? =
        when (branch.substringBefore('.').toIntOrNull()) {
            14 -> "7.1"; 15 -> "8.1"; 16 -> "9"; 17 -> "10"; 18 -> "11"
            19 -> "12"; 20 -> "13"; 21 -> "14"; 22 -> "15"; 23 -> "16"
            else -> null
        }

    // ───────── OrangeFox ─────────

    private fun orangeFox(code: String): RecoveryItem? {
        val body = getText("https://api.orangefox.download/devices/get?codename=$code") ?: return null
        val o = JSONObject(body)
        val known = o.optString("codename").equals(code, ignoreCase = true) || o.has("_id") || o.has("id")
        if (!known) return null
        val fullName = if (o.isNull("full_name")) code else o.optString("full_name").ifBlank { code }
        val unsupported = o.has("supported") && !o.optBoolean("supported", true)
        return RecoveryItem(
            name = "OrangeFox Recovery",
            url = "https://orangefox.download/device/${code.lowercase()}",
            notes = UiText.res(R.string.note_orangefox, fullName),
            status = if (unsupported) "abandoned" else "official"
        )
    }

    // ───────── TWRP ─────────

    private fun twrp(code: String): RecoveryItem? {
        val url = "https://dl.twrp.me/${code.lowercase()}/"
        val html = getText(url) ?: return null
        if (!html.contains("twrp-", ignoreCase = true)) return null
        return RecoveryItem("TWRP", url, UiText.res(R.string.note_twrp), "official")
    }

    // ───────── helpers ─────────

    private fun getText(url: String): String? {
        val request = Request.Builder().url(url).build()
        client.newCall(request).execute().use { resp ->
            return if (resp.isSuccessful) resp.body?.string() else null
        }
    }

    /** Reads only the top-level `key: value` lines of the wiki's YAML (that is all we need). */
    private fun parseYaml(text: String): Map<String, String> {
        val map = HashMap<String, String>()
        for (line in text.lineSequence()) {
            if (line.isBlank() || line[0] == ' ' || line[0] == '-' || line[0] == '#') continue
            val i = line.indexOf(':')
            if (i <= 0) continue
            map[line.substring(0, i).trim()] = line.substring(i + 1).trim().trim('\'', '"')
        }
        return map
    }

    private fun parseList(value: String?): List<String> {
        if (value == null) return emptyList()
        return value.trim().removePrefix("[").removeSuffix("]")
            .split(',')
            .map { it.trim().trim('\'', '"') }
            .filter { it.isNotEmpty() && it != "None" }
    }

    private fun normalizeModel(m: String) = m.uppercase().replace("/DS", "").replace(" ", "").trim()

    private companion object {
        val CODENAME = Regex("^[A-Za-z0-9_+.-]{1,40}$")
        const val LINEAGE_DATA = "https://raw.githubusercontent.com/LineageOS/lineage_wiki/HEAD/_data/devices"
    }
}
