package com.forgerom.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.forgerom.app.R
import com.forgerom.app.Screen
import com.forgerom.app.UiState
import com.forgerom.app.ai.BootloaderInfo
import com.forgerom.app.ai.BootloaderStatus
import com.forgerom.app.ai.RecoveryItem
import com.forgerom.app.ai.RomItem
import com.forgerom.app.device.CatalogEntry
import kotlinx.coroutines.delay

private val CardShape = RoundedCornerShape(24.dp)
private val HeroBrush = Brush.linearGradient(listOf(Color(0xFF0066FF), Color(0xFF0040B8)))
private fun Modifier.h() = padding(horizontal = 16.dp)

@Composable
fun ForgeRomApp(
    state: UiState,
    onApiKeyChange: (String) -> Unit,
    onSearch: () -> Unit,
    onOpenPicker: () -> Unit,
    onClosePicker: () -> Unit,
    onPickerQuery: (String) -> Unit,
    onSelectManual: (CatalogEntry) -> Unit,
    onUseDetected: () -> Unit
) {
    BackHandler(enabled = state.screen == Screen.PICKER) { onClosePicker() }

    AnimatedContent(
        targetState = state.screen,
        transitionSpec = {
            (fadeIn(tween(260)) + slideInVertically(tween<IntOffset>(260)) { it / 14 }) togetherWith
                fadeOut(tween(140))
        },
        label = "screen"
    ) { screen ->
        when (screen) {
            Screen.MAIN -> MainScreen(state, onApiKeyChange, onSearch, onOpenPicker, onUseDetected)
            Screen.PICKER -> PickerScreen(state, onClosePicker, onPickerQuery, onSelectManual)
        }
    }
}

// ───────────────────────── Ana ekran ─────────────────────────

@Composable
private fun MainScreen(
    state: UiState,
    onApiKeyChange: (String) -> Unit,
    onSearch: () -> Unit,
    onOpenPicker: () -> Unit,
    onUseDetected: () -> Unit
) {
    Scaffold(contentWindowInsets = WindowInsets(0, 0, 0, 0)) { inner ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Hero() }
            item { Box(Modifier.h()) { DeviceCard(state, onOpenPicker, onUseDetected) } }
            item { Box(Modifier.h()) { ApiKeyCard(state.apiKey, onApiKeyChange) } }
            item {
                Box(Modifier.h()) {
                    Button(
                        onClick = onSearch,
                        enabled = !state.searching && state.activeDevice != null,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth().height(56.dp)
                    ) {
                        Text(
                            if (state.searching) "Aranıyor…" else "ROM ve Recovery Bul",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
            if (state.searching) item { Box(Modifier.h()) { SearchingCard() } }
            state.error?.let { msg -> item { Box(Modifier.h()) { InfoCard(msg, error = true) } } }

            state.result?.let { r ->
                val bl = r.bootloader
                if (bl.status == BootloaderStatus.LOCKED) {
                    item { Box(Modifier.h()) { Appear { LockedCard(bl, onOpenPicker) } } }
                } else {
                    item { Box(Modifier.h()) { Appear { BootloaderBadge(bl) } } }
                    r.warnings.forEach { w ->
                        item { Box(Modifier.h()) { InfoCard("⚠ $w", error = true) } }
                    }
                    item { Box(Modifier.h()) { SectionTitle("Custom ROM'lar") } }
                    if (r.roms.isEmpty()) item { Box(Modifier.h()) { Text("Güvenilir bir ROM bulunamadı.") } }
                    itemsIndexed(r.roms) { i, rom -> Box(Modifier.h()) { Appear(i) { RomCard(rom) } } }

                    item { Box(Modifier.h()) { SectionTitle("Custom Recovery'ler") } }
                    if (r.recoveries.isEmpty()) item { Box(Modifier.h()) { Text("Güvenilir bir recovery bulunamadı.") } }
                    itemsIndexed(r.recoveries) { i, rec -> Box(Modifier.h()) { Appear(i) { RecoveryCard(rec) } } }
                }
            }
            item { Spacer(Modifier.navigationBarsPadding().height(24.dp)) }
        }
    }
}

@Composable
private fun Hero() {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
            .background(HeroBrush)
    ) {
        Row(
            Modifier.statusBarsPadding().padding(horizontal = 20.dp, vertical = 24.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Logo()
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("ForgeROM", style = MaterialTheme.typography.headlineMedium, color = Color.White, fontWeight = FontWeight.Bold)
                Text("Custom ROM kurulumunu kolaylaştırır", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.85f))
                Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.2f)) {
                    Text(
                        "0.1 Alpha · Öneri modu",
                        Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White
                    )
                }
            }
        }
    }
}

/** İki katmanlı logo: arka plan + ön plan (drawable-xxxhdpi içindeki PNG'ler). */
@Composable
private fun Logo() {
    val shape = RoundedCornerShape(20.dp)
    Box(Modifier.size(64.dp).border(1.5.dp, Color.White.copy(alpha = 0.35f), shape).clip(shape)) {
        Image(painterResource(R.drawable.ic_launcher_background), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

@Composable
private fun DeviceCard(state: UiState, onOpenPicker: () -> Unit, onUseDetected: () -> Unit) {
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth().animateContentSize()
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                if (state.manual != null) "CİHAZ · ELLE SEÇİLDİ" else "CİHAZ · OTOMATİK ALGILANDI",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    state.displayName,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (state.resolvingName && state.manual == null) {
                    CircularProgressIndicator(Modifier.padding(start = 10.dp).size(16.dp), strokeWidth = 2.dp)
                }
            }
            if (state.manual == null) {
                state.detected?.let { d ->
                    Text("Android ${d.androidVersion} (API ${d.sdk})", style = MaterialTheme.typography.bodySmall)
                    d.soc?.let { Text("SoC: $it", style = MaterialTheme.typography.bodySmall) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = onOpenPicker) { Text("Cihazı değiştir") }
                if (state.manual != null) TextButton(onClick = onUseDetected) { Text("Algılananı kullan") }
            }
        }
    }
}

@Composable
private fun ApiKeyCard(apiKey: String, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(apiKey.isBlank()) }
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth().animateContentSize()
    ) {
        if (expanded || apiKey.isBlank()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = onChange,
                    label = { Text("Anthropic API anahtarı") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Alpha'da anahtar sadece bu cihazda saklanır.", style = MaterialTheme.typography.bodySmall)
                if (apiKey.isNotBlank()) TextButton(onClick = { expanded = false }) { Text("Tamam") }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("API anahtarı kayıtlı ✓", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                TextButton(onClick = { expanded = true }) { Text("Değiştir") }
            }
        }
    }
}

@Composable
private fun SearchingCard() {
    val steps = listOf(
        "Cihaz bilgileri analiz ediliyor…",
        "Bootloader durumu kontrol ediliyor…",
        "XDA ve resmi kaynaklar taranıyor…",
        "Sonuçlar doğrulanıyor…"
    )
    var step by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) { delay(3500); step = (step + 1) % steps.size }
    }
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.55f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "alpha"
    )
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            AnimatedContent(targetState = step, transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(200)) }, label = "step") { i ->
                Text(
                    steps[i],
                    Modifier.alpha(pulse),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            LinearProgressIndicator(Modifier.fillMaxWidth().clip(CircleShape))
        }
    }
}

// ───────────────────────── Sonuç kartları ─────────────────────────

/** Kartı hafif gecikmeyle yumuşakça belirir. */
@Composable
private fun Appear(index: Int = 0, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(index * 70L); visible = true }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(320)) + slideInVertically(tween<IntOffset>(320)) { it / 6 }
    ) { content() }
}

@Composable
private fun LockedCard(bl: BootloaderInfo, onPick: () -> Unit) {
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🔒 Bootloader kilidi açılamıyor", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onErrorContainer)
            Text(
                bl.notes ?: "Custom ROM kurmak için bootloader kilidinin açılması gerekir. Bu model için bu mümkün görünmüyor.",
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            Text(
                "Algılanan cihaz yanlışsa ya da başka bir model için aramak istersen modeli elle seçebilirsin.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            Button(onClick = onPick, shape = RoundedCornerShape(16.dp)) { Text("Manuel model seç") }
        }
    }
}

@Composable
private fun BootloaderBadge(bl: BootloaderInfo) {
    val (title, container, content) = when (bl.status) {
        BootloaderStatus.UNLOCKABLE -> Triple("✓ Bootloader kilidi açılabilir", MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
        BootloaderStatus.CONDITIONAL -> Triple("⚠ Bootloader yalnızca koşullu açılabilir", MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer)
        else -> Triple("? Bootloader durumu doğrulanamadı", MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant)
    }
    Card(shape = CardShape, colors = CardDefaults.cardColors(containerColor = container), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = content)
            bl.notes?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = content) }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, Modifier.padding(top = 8.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun InfoCard(text: String, error: Boolean) {
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(
            containerColor = if (error) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(text, Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun StatusChip(status: String) {
    val color = when (status.lowercase()) {
        "official" -> Color(0xFF1E9E5A)
        "unofficial" -> Color(0xFFE08A00)
        else -> Color(0xFF8A8F98)
    }
    Surface(shape = CircleShape, color = color.copy(alpha = 0.15f), contentColor = color) {
        Text(status, Modifier.padding(horizontal = 10.dp, vertical = 3.dp), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun RomCard(rom: RomItem) {
    val uriHandler = LocalUriHandler.current
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(rom.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                rom.androidVersion?.let {
                    Text("Android $it", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
                rom.status?.let { StatusChip(it) }
            }
            rom.notes?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            FilledTonalButton(onClick = { uriHandler.openUri(rom.url) }) { Text("Kaynağı aç") }
        }
    }
}

@Composable
private fun RecoveryCard(rec: RecoveryItem) {
    val uriHandler = LocalUriHandler.current
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(rec.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            rec.notes?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            FilledTonalButton(onClick = { uriHandler.openUri(rec.url) }) { Text("Kaynağı aç") }
        }
    }
}

// ───────────────────────── Manuel model seçimi ─────────────────────────

@Composable
private fun PickerScreen(
    state: UiState,
    onBack: () -> Unit,
    onQuery: (String) -> Unit,
    onSelect: (CatalogEntry) -> Unit
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().imePadding()) {
            Box(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                    .background(HeroBrush)
            ) {
                Column(Modifier.statusBarsPadding().padding(start = 8.dp, end = 20.dp, bottom = 20.dp)) {
                    TextButton(onClick = onBack, colors = ButtonDefaults.textButtonColors(contentColor = Color.White)) {
                        Text("← Geri")
                    }
                    Text(
                        "Cihazını seç",
                        Modifier.padding(start = 12.dp),
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            OutlinedTextField(
                value = state.pickerQuery,
                onValueChange = onQuery,
                placeholder = { Text("Ticari ad, model veya kod adı (ör. S20 FE, r8q)") },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().padding(16.dp).focusRequester(focus)
            )
            if (state.pickerLoading) LinearProgressIndicator(Modifier.h().fillMaxWidth().clip(CircleShape))

            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (state.pickerQuery.isBlank()) {
                    item { Text("Aramak için yazmaya başla.", style = MaterialTheme.typography.bodyMedium) }
                } else if (!state.pickerLoading && state.pickerResults.isEmpty()) {
                    item { Text("Sonuç bulunamadı. Farklı bir yazılış dene.", style = MaterialTheme.typography.bodyMedium) }
                }
                items(state.pickerResults) { e ->
                    Card(
                        onClick = { onSelect(e) },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(e.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text("${e.model} · ${e.codename}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
